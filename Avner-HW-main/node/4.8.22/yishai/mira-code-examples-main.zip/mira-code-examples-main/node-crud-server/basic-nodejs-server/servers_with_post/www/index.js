console.log("hi from server js");
